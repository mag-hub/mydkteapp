
/** Auto-generated url.js */
var REDIRECT_URI = false;
window.location.hash = window.location.hash.replace(/\?__goto__=(.*)/, "");
var CURRENT_LANGUAGE = AVAILABLE_LANGUAGES.indexOf(language) >= 0 ? language : 'en';
DOMAIN = 'http://appmaker.etrx.club';
APP_KEY = '5a254d53e9091';
BASE_PATH = '/'+APP_KEY;

var BASE_URL = DOMAIN + BASE_PATH;
var IMAGE_URL = DOMAIN + '/';