App.constant("AUTH_EVENTS", {
    loginSuccess: "auth-login-success",
    logoutSuccess: "auth-logout-success",
    loginStatusChanged: "auth-login-status-changed",
    notAuthenticated: "auth-not-authenticated"
});
