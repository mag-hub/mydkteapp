App.constant("CACHE_EVENTS", {
   clearSocialGaming: "clear-cache-socialgaming",
   clearDiscount: "clear-cache-discount"
});